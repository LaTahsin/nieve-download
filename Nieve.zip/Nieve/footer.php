<?php
global $nieve;
 ?>

    
    <!--Start Footer-->
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="copyright">
                        <p><?php  echo $nieve['footer-text'];?></p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!--End Footer-->

    <?php wp_footer();?>
</body>